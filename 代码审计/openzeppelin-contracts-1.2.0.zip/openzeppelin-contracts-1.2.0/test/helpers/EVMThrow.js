export default 'invalid opcode'
